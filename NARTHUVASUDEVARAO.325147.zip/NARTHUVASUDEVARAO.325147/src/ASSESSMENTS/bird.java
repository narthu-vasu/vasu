package ASSESSMENTS;

public class bird {
	public int noleg;
	public String food;
    public String name;
	public String gender;
    public int age;
	public String color;
	
	
	public void flys() {
		System.out.println("The Bird Flys\n");
	}
	
	public void eat() {
		System.out.println("The Bird eats\n");
	}	
	
	public void display() {
		System.out.println(" No of legs: " +this.noleg + " Skin color: "+ this.color + " Food: " + this.food + " Name: "+this.name 
							+ " Gender: " + this.gender + " Age: " + this.age );
	}
	

}
