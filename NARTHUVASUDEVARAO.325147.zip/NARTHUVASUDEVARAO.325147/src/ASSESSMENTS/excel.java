package ASSESSMENTS;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel {
ArrayList<product> al_1=new ArrayList<product>();
File f=new File("D:\\sample\\Book3.xlxs");


}
