package ASSESSMENTS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import DAY3.Student;

public class excel_opp {


	public ArrayList<Student1> read_xll(){
	
		ArrayList<Student1> std_al=new ArrayList<Student1>();
		for(int i=1;i<=4;i++) {
			Student1 s=new Student1();
	try {
		File f=new File("D:\\sample\\Book2.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet1");
		XSSFRow r=sh.getRow(i);
		XSSFCell c=r.getCell(0);
		s.rollnum=(int) c.getNumericCellValue();
		
		XSSFCell c1=r.getCell(1);
		s.name=c1.getStringCellValue();
		
		XSSFCell c2=r.getCell(2);
		s.m1=(int) c2.getNumericCellValue();
		
		XSSFCell c3=r.getCell(3);
		s.m2=(int) c3.getNumericCellValue();
		
		XSSFCell c4=r.getCell(4);
		s.m3=(int) c4.getNumericCellValue();
	   s.average();
	   System.out.println(s.avg);
	   std_al.add(s);
		//FileOutputStream fos=new FileOutputStream (f);
		//wb.write(fos);
		System.out.println(s.name);
	}
	catch(FileNotFoundException e) {
		e.printStackTrace();
		
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
		return std_al;
	}
	public void write_xl(ArrayList<Student1> std_al1) {
		int row=1;
	
		try {
			File f=new File("D:\\sample\\Book2.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
for(Student1 s1:std_al1) {
			XSSFRow r=sh.getRow(row);
			XSSFCell c=r.createCell(5);
			c.setCellValue((double)s1.avg);
			row++;
			FileOutputStream fos=new FileOutputStream (f);
			wb.write(fos);
			}
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	

}


