package ASSESSMENTS;

public class parrot extends bird{
	int noleng;
	int weight;
	
	public void imitate() {
		System.out.println("Parrot imitate sounds ");
	}
	

	public void screams() {
		System.out.println("Parrot scream noise");
	}
	
	
	


	public parrot(int noleng2, int weight2, int age, String color, String food, String gender, String name, int noleg) {
		// TODO Auto-generated constructor stub
		this.noleng=noleng2;
		this.weight=weight2;
	    this.age=age;
		this.color=color;
		this.food=food;
		this.gender=gender;
		this.name=name;
		this.noleg=noleg;
		display();
	}


	public void display() {
		System.out.println(" Name: "+this.name +" No of legs: " +this.noleg+ " Skin color: "+ this.color + " Food: " + this.food 
							+ " Gender: " + this.gender + " Age: " + this.age );
		
		System.out.println(" Length of trunk : "+ this.noleng + " Length of tusks: " + this.weight);
	}


}
