package ASSESSMENTS;

public class pgm10 {

}
