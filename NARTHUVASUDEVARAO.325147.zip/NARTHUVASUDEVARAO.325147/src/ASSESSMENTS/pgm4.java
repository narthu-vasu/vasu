package ASSESSMENTS;

import java.util.ArrayList;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> al_1=new ArrayList<Integer>();
		for(int i=10;i<=30;i++) {
			if(i%2==0) {
				al_1.add(i);
			}
		}
		System.out.println(al_1);

	}

}
