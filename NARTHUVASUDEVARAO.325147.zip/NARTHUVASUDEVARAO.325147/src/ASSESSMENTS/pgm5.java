package ASSESSMENTS;

import java.util.Scanner;

public class pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Scanner sc=new Scanner(System.in);
	//	int n=sc.nextInt();
//System.out.println(n);
for(int i=1;i<=999;i++)
   arm(i);
	}
	public static void arm(int i) {
		int s=i;
		int s3=0;
		
	
		while(i>0) {
		
		int m=i%10;
			
			i=i/10;
	
			int s1=m*m*m;
			 s3=s3+s1;
		}
	
		if(s==s3) {
			System.out.println(s+"armstrong num");
		}
	}

}
