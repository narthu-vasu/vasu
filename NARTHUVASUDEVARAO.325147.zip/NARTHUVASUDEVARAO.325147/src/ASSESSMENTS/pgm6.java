package ASSESSMENTS;

public class pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int m[]= {23,44,84,37,91,18};
int s=0;
for(int i=0;i<6; ) {
	if((m[i]%2)!=0) {
		 s=s+m[i];
	}
	i=i+2;
}
System.out.println(s);
	}

}
