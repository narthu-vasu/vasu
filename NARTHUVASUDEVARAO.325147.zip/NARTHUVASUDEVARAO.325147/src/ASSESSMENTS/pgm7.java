package ASSESSMENTS;

public class pgm7 {
	public static void main(String[] args) {
	student2 s1=new student2(1,"vasu",83,89);
	
	student2 s2=new student2(2,"ramu",43,51);
	
	student2 s3=new student2(3,"vasu",79,91);
	//System.out.println(s1.avg);
	//System.out.println(s2.avg);
	//System.out.println(s3.avg);
	if(s1.avg>65) {
		System.out.println(s1.rollno+" "+s2.name+" "+s1.avg);
	}
	if(s2.avg>65) {
		System.out.println(s2.rollno+" "+s2.name+"  "+s2.avg);
	}
	if(s3.avg>65) {
		System.out.println(s3.rollno+" "+s3.name+" "+s3.avg);
	}
}
}
