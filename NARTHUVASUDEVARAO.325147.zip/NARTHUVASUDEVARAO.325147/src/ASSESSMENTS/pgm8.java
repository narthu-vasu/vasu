package ASSESSMENTS;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		parrot p1 = new parrot(30,577,40,"green","fruits","male","parrrot1",2);
		parrot p2 = new parrot(22,700,30,"green_red","fruits","male","parrot2",2);
		parrot p3 = new parrot(40,850,40,"Red","fruits","female","parrot3",2);
		owl o1 = new owl(30,520,30,"brown","insects","male","owl1",2);
		owl o2= new owl(30,630,50,"Black","insects","male","owl2",2);
	
		p1.eat();
		p1.flys();
		
		p2.imitate();
		p2.flys();
		
		p3.eat();
		p3.screams();

		o1.eat();
		o2.hunt();
	
		

	}

	}


