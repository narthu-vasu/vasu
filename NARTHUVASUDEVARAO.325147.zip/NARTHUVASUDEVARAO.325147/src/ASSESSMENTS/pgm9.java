package ASSESSMENTS;

import java.util.ArrayList;

public class pgm9 {

		String l="I have learnt loops,oops concept,inheritance,exception handling,arraylist and string handling ";
		 public ArrayList<String> get_each_word(String str)
		 {
			 ArrayList<String> al_str=new ArrayList<String>();
			 int p1=0,p2;
			 for(int i=0;i<str.length();i++)
			 {
				 if(str.charAt(i)==' '||str.charAt(i)==',')
				 {
					 p2=i;
					 al_str.add(str.substring(p1,p2));
					 p1=p2+1;
				 }
			 }
			// al_str.add(str.substring(index1,str.length()));
			 return al_str;
		 }
		 public ArrayList<String> count_vowels(ArrayList<String> s)
		 {
			 ArrayList<String> al_str =new ArrayList<String>();
			 for(int i=0;i<s.size();i++)
			 {
				 String s1=s.get(i);
				 int count=0;
				 for(int j=0;j<s1.length();j++)
				 {
					if(s1.charAt(j)=='a'||s1.charAt(j)=='e'||s1.charAt(j)=='i'||s1.charAt(j)=='o'||s1.charAt(j)=='u')
						count++;
				 }
				 if(count>=3)
					 al_str.add(s1);
			 }
			 return al_str;
		 }
		
	 
		public static void main(String[] args) {
			pgm9 p1=new pgm9();
			ArrayList<String> a1=p1.get_each_word(p1.l);
			ArrayList<String> a2=p1.count_vowels(a1);
			System.out.println("Words having more than 2vowels :");
			//for(String s :a2)
		for(int j=0;j<a2.size();j++)
				System.out.println(a2.get(j));

		}
	

}
