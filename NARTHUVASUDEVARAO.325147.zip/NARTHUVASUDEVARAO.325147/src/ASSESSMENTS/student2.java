package ASSESSMENTS;

public class student2 {
	public int rollno;
	public String name;
	public int java;
	public int selenium;
	public float avg;
	public  student2(int rollno,String name,int java,int selenium) {
		this.rollno=rollno;
		this.name=name;
		this.java=java;
		this.selenium=selenium;
		average();
	}
	
public float average() {
	return avg=(java+selenium)/2;
}
	
}
