package ASSESSMENTS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel {
	public ArrayList<product> read_xll(){
		
		ArrayList<product> std_al=new ArrayList<product>();
		for(int i=1;i<=3;i++) {
			product s=new product();
	try {
		File f=new File("D:\\sample\\Book3.xlsx");
		FileInputStream fis=new FileInputStream(f);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sh=wb.getSheet("Sheet2");
		XSSFRow r=sh.getRow(i);
		XSSFCell c=r.getCell(0);
		s.productid=(int) c.getNumericCellValue();
		
		XSSFCell c1=r.getCell(1);
		s.productname=c1.getStringCellValue();
		
		XSSFCell c2=r.getCell(2);
		s.per_unit_rate=(int) c2.getNumericCellValue();
		
		XSSFCell c3=r.getCell(3);
		s.units_purchased=(int) c3.getNumericCellValue();
		
	
	   s.price();
	   System.out.println(s.p);
	   if(s.p>25000) {
		   s.product_grade="gradeB";
	   }
	   else {
		   s.product_grade="gradeA";
	   }
	   std_al.add(s);
		//FileOutputStream fos=new FileOutputStream (f);
		//wb.write(fos);
		//System.out.println(s.name);
	}
	catch(FileNotFoundException e) {
		e.printStackTrace();
		
		
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}
		return std_al;
	}
	public void write_xl(ArrayList<product> al_1) {
		int row=1;
	
		try {
			File f=new File("D:\\sample\\Book3.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet2");
for(product s:al_1) {
			XSSFRow r=sh.getRow(row);
			XSSFCell c=r.createCell(4);
			c.setCellValue((double)s.p);
			XSSFCell c1=r.createCell(5);
			c1.setCellValue(s.product_grade);
			row++;
			FileOutputStream fos=new FileOutputStream (f);
			wb.write(fos);
			}
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	

}
