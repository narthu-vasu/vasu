package ASSESSMENTS;

public class owl extends bird {
	int leng;
	int weight;
	
	public void rotatesneck() {
		System.out.println("Owl rotates neck 270 degrees");
	}
	

	public void hunt() {
		System.out.println("Owl hunts other Owls");
	}
	
	
		
		
	public owl(int leng, int weight,int age, String color, String food, String gender, String name, int noleg) {
	
		    this.leng=leng;
		    this.weight=weight;
		    this.age=age;
			this.color=color;
			this.food=food;
			this.gender=gender;
			this.name=name;
			this.noleg=noleg;
			display();
	}


	public void display() {
		System.out.println(" Name: "+this.name+" No of legs: " +this.noleg + 
				           " Skin color: "+ this.color + " Food: " + this.food   
							+ " Gender: " + this.gender + " Age: " + this.age +
		                     " Length of teeth : "+ this.leng + " Length of claws : " + this.weight);
	}


}
