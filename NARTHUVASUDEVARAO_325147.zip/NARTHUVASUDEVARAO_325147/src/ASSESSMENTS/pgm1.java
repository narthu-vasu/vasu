package ASSESSMENTS;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a1[]=new int[10];
		int a2[]=new int[10];
		int k=0;
		int c=0;
		for(int i=10;i<=30;i++) {
			if(i%3==0) {
				//System.out.println(i);
				
				a1[k]=i;
				k++;
				
			}
			if(i%5==0) {
				//System.out.println(i);
				
				a2[c]=i;
				c++;
				
			}
			
		}
		for(int j=0;j<k;j++) {
		System.out.print(a1[j]+" ");
		}
		System.out.println(" ");
		for(int j=0;j<c;j++) {
			System.out.print(a2[j]+" ");
			}
		System.out.println(" ");
		for(int j=0;j<c;j++) {
			for( int l=0;l<k;l++) {
				if((a2[j]+a1[l])>30&&(a2[j]+a1[l])<40) {
					System.out.println(a1[l]+" "+a2[j]+" "+(a1[l]+a2[j]));
				}
			}
			
		}
		
		
	}

}
