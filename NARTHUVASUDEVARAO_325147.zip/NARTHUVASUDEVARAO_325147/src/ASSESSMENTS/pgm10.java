package ASSESSMENTS;

import java.util.ArrayList;

public class pgm10 {
	public static void main(String [] args) {
excel ex=new excel();
ArrayList<product> al_1=ex.read_xll();
ex.write_xl(al_1);
}
}
