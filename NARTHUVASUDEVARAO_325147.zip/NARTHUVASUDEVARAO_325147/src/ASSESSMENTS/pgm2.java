package ASSESSMENTS;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String l="hello i am working at globallogic ";
		extract_word(l);
	}
	
public static String[] extract_word(String l) {
		String s;
		int c=0;
		int p=0;
		for(p=0;p<l.length();p++) {
			if(l.charAt(p)==' ') {
				s=l.substring(c,p);
				//System.out.println(s);
				count_print(s);
				c=p;
				c++;
				
				//count_print(s);
			}
		}
return null;
	}

public static void count_print(String s) {
	int k=s.length();
	if(k>5) {
		System.out.println(s);
	}
	//return null;
}
}
