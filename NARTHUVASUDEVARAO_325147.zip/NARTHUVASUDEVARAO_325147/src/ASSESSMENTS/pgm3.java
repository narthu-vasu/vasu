package ASSESSMENTS;

import java.util.ArrayList;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		excel_opp excell=new excel_opp();
		
		
		ArrayList<Student1> std_al1=new ArrayList<Student1>();
				       std_al1=excell.read_xll();
				       
				        excell.write_xl(std_al1);

	}

}
