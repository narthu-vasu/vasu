package ASSESSMENTS;

public class product {

	public int productid;
	public String productname;
	public int per_unit_rate;
	public int units_purchased;
	public int p;
	public String product_grade;
	public float price() {
		return p=per_unit_rate*units_purchased;
	}
}
