package DAY1;

import java.util.Scanner;

public class pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c;
		System.out.println("enter any charceter");
 Scanner sc=new Scanner(System.in);
 c=sc.next().charAt(0);
 if(c=='a'||c=='e'||c=='i'||c=='0'||c=='u')
	 System.out.println("it is a vowel");
 else
	 System.out.println("it is not a vowel");
	}

}
