package DAY1;

import java.util.Scanner;

public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a;
		int b;
		int c;
		 Scanner sc=new Scanner(System.in);
			System.out.println("enter number");
			a=sc.nextInt();
			System.out.println("enter number");
			b=sc.nextInt();
			System.out.println("enter number");
			c=sc.nextInt();
			/*
			 k=((a>b)?((a>c)?a:c):(b)
			 */
		if(a>b&&a>c)
			System.out.println("a is biggest");
		else if(b>c)
			System.out.println("b is biggest");
		else
			System.out.println("c is biggest");
	}

}
