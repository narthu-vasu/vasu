package DAY1;

import java.util.Scanner;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a;
		int rev=0;
		 Scanner sc=new Scanner(System.in);
			System.out.println("enter number");
			a=sc.nextInt();
       while(a!=0) {
    	   rev=rev*10;
    	   rev=rev+a%10;
    	   a=a/10;
       }
       System.out.println("revers number"+rev);
	
    if(rev==a)
    	System.out.println("palindrome");
    else
    	System.out.println("not a palindrome");
}
}
