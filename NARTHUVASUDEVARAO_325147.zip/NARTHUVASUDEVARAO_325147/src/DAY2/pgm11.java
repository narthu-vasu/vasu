package DAY2;

public class pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=1,k,s=0,num=11;
		boolean b;
		while(c<=10) {
			b=isprime(num);
			if(b==true) {
				
				s=s+num;
				c++;
			}
			num++;
			System.out.println(s);
		}

	}
	public static boolean isprime(int n) {
		int i;
		boolean prime=true;
		for(i=2;i<(n/2);i++) {
			if((n%2)==0) {
				prime=false;
				break;
			}
		}
		return prime;
			}

}
