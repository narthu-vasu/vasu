package DAY2;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i;
		for(i=0;i<5;i++)
			System.out.println(i);
	}

}
