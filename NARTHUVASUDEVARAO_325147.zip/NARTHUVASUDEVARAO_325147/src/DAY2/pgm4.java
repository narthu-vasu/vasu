package DAY2;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i,s=0;
		for(i=10;i<=50;i++)
		{
			if((i%5)==0) {
				System.out.print(i+"+");
			s=s+i;
			}
		}
		System.out.print("="+s);

	}

}
