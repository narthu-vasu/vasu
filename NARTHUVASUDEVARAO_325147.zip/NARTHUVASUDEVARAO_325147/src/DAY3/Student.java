package DAY3;

public class Student {

 public int rollnum;
public String name;
 public int m1;
public int m2;
public float avg;


public  void average() {
	 avg=(float)(m1+m2)/2;
	//return avg;
}
}
/*
public Student(int rollnum,String name,int m1,int m2) {
	this.rollnum=rollnum;
	this.name=name;
	this.m1=m1;
	this.m2=m2;
}
}*/
