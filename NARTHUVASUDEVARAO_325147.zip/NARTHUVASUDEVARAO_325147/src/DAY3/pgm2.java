package DAY3;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean n;
		int  std[]= {21,34,91,59,25,29,74,49,82};
		int i,s=0;
		for(i=0;i<=8;i++)
		{
		n=evencheck(std[i]);
		if(n==true) {
			s=s+std[i];
		}
		}
		System.out.println(s);

	

}
public static boolean evencheck(int y)
{
		if(y%2==0)
		{
	return true;
	}
		else return false;
}
}
