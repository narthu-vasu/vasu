package DAY3;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j,max=0;
		int a[]=new int[10];
		int marks[][]= {{87,65,79,60},{91,72,73,85},{94,80,83,84}};
		for(i=0;i<=2;i++)
		{
			for(j=0;j<=3;j++)
			{
				System.out.print(marks[i][j]+" ");
				}
			
			System.out.println(" ");
		}
			for(int l=0;l<=2;l++)
			{
				for(int k=0;k<=3;k++)
				{
					a[k]=marks[l][k];
				}
			
			maxrowval(a);
			}
	}
		
	
public static void maxrowval(int a[]) {
	int r[]=new int[4];
	for(int n=0;n<=3;n++) {
		r[n]=a[n];
	}
	int max;
	max=r[0];
	for(int x=1;x<3;x++)
	{
		
			if(r[x]>r[x+1]) {
				max=r[x];
			}
		
	}
	System.out.println("max val of each row is"+max);
	
		}
}



