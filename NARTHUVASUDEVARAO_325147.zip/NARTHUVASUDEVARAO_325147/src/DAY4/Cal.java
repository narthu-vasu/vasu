package DAY4;

public class Cal {

public int add(int x,int y) {
	int z=x+y;
	return z;
}

public float add(float x,float y) {
	float z=x+y;
	return z;
}

}
