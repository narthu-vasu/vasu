package DAY4;

public class Student {

	int rollnum;
	String name;
	int m1;
	int m2;
	float avg;

	
public Student(int rollnum,String name,int m1,int m2)
{
	this.rollnum=rollnum;
	this.name=name;
	this.m1=m1;
	this.m2=m2;
	}
public void display() {
	System.out.println("rollnum::"+rollnum);
	System.out.println("name::"+name);
	System.out.println("m1::"+m1);
	System.out.println("m2::"+m2);
}
public static void main(String[] args)
{
Student s=new Student(1,"vasu",85,86);	
s.display();
}
}

