package DAY4;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,j;
		for(i=5;i>=1;i--)
		{
			for(int c=0;c<i;c++)
			{
				System.out.print(" ");
			}
			
			for(j=5;j>=i;j--)
			{
				
				System.out.print("1"+" ");
			}
			
			System.out.println(" ");
		}
		for(i=1;i<=5;i++)
		{
			for(int c=0;c<i;c++)
			{
				System.out.print(" ");
			}
			for(j=5;j>=i;j--)
			{
				
				
				System.out.print("1"+" ");
			}
			System.out.println(" ");
		}

	}

}
