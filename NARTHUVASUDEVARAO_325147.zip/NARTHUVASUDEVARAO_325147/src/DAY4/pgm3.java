package DAY4;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="i am working with globallogic in noida ";
	int c=0,p=0;
	int a[]=new int[50];
	String s2;
	while(p!=-1) {
		p=s1.indexOf(" ",p+1);
		c++;
		a[c+1]=p;
		
	}
	System.out.println("number of spaces="+c);
	for( int i=0;i<=c;i++) {
	if(i!=8){
		s2=s1.substring(a[i], a[i+1]);
		System.out.println(s2);
	}
	}

	}

	}


