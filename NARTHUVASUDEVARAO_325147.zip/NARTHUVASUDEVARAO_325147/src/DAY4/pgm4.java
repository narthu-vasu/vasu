package DAY4;

public class pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
Cal c=new Cal();
int s=c.add(5, 7);
System.out.println(s);
float s1=c.add(5.2f, 7.2f);
System.out.println(s1);
	}

}
