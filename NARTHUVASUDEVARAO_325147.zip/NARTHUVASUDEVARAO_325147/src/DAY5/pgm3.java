package DAY5;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			/*int n=10,m=0,s=0;
			s=n/m;
			System.out.println(s);*/
			int a[]= {1,2,3};
			System.out.println(a[3]);
		}
		catch(ArrayIndexOutOfBoundsException e1) {
			System.out.println("ArrayIndexOutOfBoundsException is occured");
		}
		catch(ArithmeticException e2) {
			System.out.println("ArithmeticException is occured");
		}
	}

}
