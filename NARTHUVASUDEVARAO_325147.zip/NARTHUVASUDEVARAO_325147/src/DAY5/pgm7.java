package DAY5;

import DAY3.Student;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		read_xl excell=new read_xl();
for(int i=1;i<=3;i++) {

       Student s1=excell.read_xll(i);
        s1.average();
        excell.write_xl(s1,i);
	}
	}

}
