package DAY6;

import java.util.ArrayList;

import DAY6.student;

public class ArrayList_2 {
ArrayList<student> std_al=new ArrayList<student>();
	
	public void create() {
		student s1=new student(1,"ramesh",82,79);
		student s2=new student(2,"ramu",83,79);
		std_al.add(s1);
		std_al.add(s2);
	}
	public void display() {
		for(student s:std_al) {
			//s.name="vasu";
			s.average();
			System.out.println("rollnum "+s.rollnum
	            				+"name "+s.name
					             +"m1 "+s.m1
					               +"m2 "+s.m2
					               +"avg "+s.avg);
		}
	}
	public void display1() {
		for(student s3:std_al) {
			//s.name="vasu";
			//s.average();
			System.out.println("rollnum "+s3.rollnum
	            				+"name "+s3.name
					             +"m1 "+s3.m1
					               +"m2 "+s3.m2
					               +"avg "+s3.avg);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
      ArrayList_2 al=new ArrayList_2();
      al.create();
      al.display();
      al.display1();
	}

}
