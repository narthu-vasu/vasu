package DAY6;

public class Elephant extends Animal{
	int lotrunk;
	int lotusks;
	int age;
	String color;
	 String food;
	String gender;
	 String name;
	int noleg;
	
	public void swim() {
		System.out.println("Elephant swims");
	}
	

	public void spraying() {
		System.out.println("Elephant sprays using trunks");
	}
	public void acts() {
		System.out.println("This Elephant acts");
	}
	
		
	public Elephant(int lot, int lotusks,	int age, String color, String food,	String gender,	 String name,int noleg) {
	
		this.lotrunk=lot;
		this.lotusks=lotusks;
		this.age=age;
		this.color=color;
		this.food=food;
		this.gender=gender;
		this.noleg=noleg;
	}


	public void display() {
		System.out.println(" Name: "+this.name
				+" No of legs: " 	+this.noleg 
				+" Skin color: "	+ this.color 
				+ " Food: " + this.food 
			    + " Gender: "+ this.gender 
			    + " Age: " + this.age 
		        +" Length of trunk : "+ this.lotrunk 
		        + " Length of tusks: " + this.lotusks);
	}
}

	

	


