package DAY6;

public class Tiger extends Animal {

	int lotteeth;
	int lc;
    int age;
	String color;
	String food;
	String gender;
	String name;
	int noleg;
	
	public void roar() {
		System.out.println("Tiger Roars");
	}
	

	public void climb() {
		System.out.println("Tiger climbs tree");
	}
	
	public void mauls() {
		System.out.println("Tiger mauls its prey");
	}
	
		
		
	public Tiger(int lott, int loc,int age,String color,String food,String gender,	String name,int noleg) {
	
		this.lotteeth=lott;
		this.lc=loc;
		this.age=age;
		this.color=color;
		this.food=food;
		this.gender=gender;
		this.name=name;
		this.noleg=noleg;
	}


	public void display() {
		System.out.println(" No of legs: " +this.noleg
				+ " Skin color: "+ this.color   
				+ " Food: " + this.food 
				+ " Name: "+this.name 
				+ " Gender: " + this.gender 
				+ " Age: " + this.age 
		        +" Length of teeth : "+ this.lotteeth 
		        + " Length of claws : " + this.lc);
	}

}

