package DAY6;

import java.util.ArrayList;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> str_al=new ArrayList<String>();
		str_al.add("vasu");
		str_al.add("abc");
		str_al.add("xyz");
		System.out.println(str_al);
		str_al.remove("abc");
		System.out.println(str_al);
		str_al.add(2,"globallogic");
		System.out.println(str_al);
		
	}

}
