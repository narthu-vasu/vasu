package DAY6;
public class pgm3{

public static void main(String[] args) {
	// TODO Auto-generated method stub
	Elephant e1 = new Elephant(2,4,20,"black","treebark","male","elephant1",4);
	Elephant e2 = new Elephant(3,5,25,"black","twings","female","elephant2",4);
	Tiger t1 = new Tiger(4,3,18,"white","fish","male","tiger1",4);
	Tiger t2 = new Tiger(3,5,10,"red","fishes","female","tiger2",4);
	e1.display();
	e1.eats();
	e1.swim();
	e2.display();
	e2.eats();
	e2.swim();
	e2.runs();
	e2.acts();
	t1.display();
	t1.climb();
	t1.eats();
	t1.mauls();
	t1.roar();
	t2.display();
	t1.climb();
	t1.eats();
	t1.mauls();
	t1.roar();
	t1.runs();
	

}

}

