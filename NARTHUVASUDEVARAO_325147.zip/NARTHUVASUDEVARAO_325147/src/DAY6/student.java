package DAY6;

public class student {

		 public int rollnum;
		public String name;
		 public int m1;
		public int m2;
		public float avg;


		public void average() {
			this.avg=(this.m1+this.m2)/2;
			
		}
		public student(int rollnum,String name,int m1,int m2) {
			this.rollnum=rollnum;
			this.name=name;
			this.m1=m1;
			this.m2=m2;
		}
		


	}


