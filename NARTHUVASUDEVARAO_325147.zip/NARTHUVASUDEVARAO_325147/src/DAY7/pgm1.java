package DAY7;

import java.util.ArrayList;

import DAY3.Student;
import DAY5.read_xl;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		excel_op excell=new excel_op();
		
		
ArrayList<Student> std_al1=new ArrayList<Student>();
		       std_al1=excell.read_xll();
		       
		        excell.write_xl(std_al1);
			

	}

}
