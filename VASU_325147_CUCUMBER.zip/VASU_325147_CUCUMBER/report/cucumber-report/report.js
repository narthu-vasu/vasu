$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("a.feature");
formatter.feature({
  "line": 1,
  "name": "AUT Login",
  "description": "",
  "id": "aut-login",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 2,
  "name": "Login with valid data",
  "description": "",
  "id": "aut-login;login-with-valid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 3,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 4,
  "name": "User enters Login data and clicks ok button",
  "keyword": "When "
});
formatter.step({
  "line": 5,
  "name": "home page is displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test.login_page_is_displayed()"
});
formatter.result({
  "duration": 8570178700,
  "status": "passed"
});
formatter.match({
  "location": "test.user_enters_Login_data_and_clicks_ok_button()"
});
formatter.result({
  "duration": 1939125000,
  "status": "passed"
});
formatter.match({
  "location": "test.home_page_is_displayed()"
});
formatter.result({
  "duration": 52734900,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "Login with invalid data",
  "description": "",
  "id": "aut-login;login-with-invalid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "User enters invalid Login data and clicks ok button",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "home page is not displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test.login_page_is_displayed()"
});
formatter.result({
  "duration": 8485616700,
  "status": "passed"
});
formatter.match({
  "location": "test1.u2()"
});
formatter.result({
  "duration": 2297063900,
  "status": "passed"
});
formatter.match({
  "location": "test1.d2()"
});
formatter.result({
  "duration": 113800,
  "status": "passed"
});
});