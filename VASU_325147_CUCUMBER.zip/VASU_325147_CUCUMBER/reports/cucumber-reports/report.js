$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("a.feature");
formatter.feature({
  "line": 1,
  "name": "AUT Login",
  "description": "",
  "id": "aut-login",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 2,
  "name": "Login with valid data",
  "description": "",
  "id": "aut-login;login-with-valid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 3,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 4,
  "name": "User enters Login data and clicks ok button",
  "keyword": "When "
});
formatter.step({
  "line": 5,
  "name": "home page is displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test.login_page_is_displayed()"
});
formatter.result({
  "duration": 9037223400,
  "status": "passed"
});
formatter.match({
  "location": "test.user_enters_Login_data_and_clicks_ok_button()"
});
formatter.result({
  "duration": 1933606700,
  "status": "passed"
});
formatter.match({
  "location": "test.home_page_is_displayed()"
});
formatter.result({
  "duration": 49450300,
  "error_message": "java.lang.AssertionError: The following asserts failed:\n\texpected [vasunarthu17@gmail.com] but found [vasunarthu7@gmail.com]\r\n\tat org.testng.asserts.SoftAssert.assertAll(SoftAssert.java:43)\r\n\tat STEP_DEF.test.home_page_is_displayed(test.java:38)\r\n\tat ✽.Then home page is displayed(a.feature:5)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 7,
  "name": "Login with invalid data",
  "description": "",
  "id": "aut-login;login-with-invalid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "Login page is displayed",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "User enters invalid Login data and clicks ok button",
  "keyword": "When "
});
formatter.step({
  "line": 10,
  "name": "home page is not displayed",
  "keyword": "Then "
});
formatter.match({
  "location": "test.login_page_is_displayed()"
});
formatter.result({
  "duration": 8156074800,
  "status": "passed"
});
formatter.match({
  "location": "test1.u2()"
});
formatter.result({
  "duration": 2076102600,
  "status": "passed"
});
formatter.match({
  "location": "test1.d2()"
});
formatter.result({
  "duration": 706900,
  "status": "passed"
});
});