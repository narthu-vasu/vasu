package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	WebDriver dr;
	@When("^User enters invalid Login data and clicks ok button$")
	public void u2() throws Throwable {
		dr=test.dr;
	    dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("vasunarthu7@gmail.com");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("bbjdsnjsdj");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	  
	}
	@Then("home page is not displayed")
	public void d2() throws Throwable {
	System.out.println("home page is not displayed");
		   }
	
}
