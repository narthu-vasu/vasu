package POC;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
public class NewTest1 {
	  login_page lp;
	  home_page hp;
	  cart_page cp;
	  product_page pp;
	  WebDriver dr;
	  placeorder po;
	  cancel_page cp1;
	  excel_op eo;
	  @BeforeClass
	  public void bc() {
		  System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		  dr=new ChromeDriver();
		  dr.get("https://www.Flipkart.com");
			dr.manage().window().maximize();
		  lp=new login_page(dr);
		  hp=new home_page(dr);
		 cp=new cart_page(dr);
		  pp=new product_page(dr);
		  po=new placeorder(dr);
		  cp1=new cancel_page(dr);
		  eo=new excel_op();
	  }
	  @Test
	  public void t1() {
		  lp.login("8790819839","vasu1234");
	  }
	  @Test
	  public void t2() {
		  hp.verifyuser();
		  hp.search();
	  }
	  @Test
	  public void t3() {
		  pp.click_rate();
		  pp.add_to_cart();
		 
	  }
		 
    /*  String hnd=dr.getWindowHandle();
      for(String handle:dr.getWindowHandles()) {
    	  dr.switchTo().window(handle);
      }*/
	
		 /*   ArrayList<String> tabs2 = new ArrayList<String> (dr.getWindowHandles());
		    dr.switchTo().window(tabs2.get(0));*/
		  @Test
		  public void t4() {
			  cp.add_to_cart1();
			  cp.verify_product();
			  
		  }
		  @Test
		  public void t5() {
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			  po.placeorder1();
			  po.delivery();
			 
		  }
		
		//  cp1.ordersuccessverify();
		  @Test
		  public void t6() {
			  cp1.cancel();
			  cp1.cancelverify();
			 
		  }
		
		/*  hp.click_cart();
		 String s= cp.verify();
		 System.out.println(s);	
		 SoftAssert sa=new SoftAssert();
			sa.assertEquals(s,"");
			sa.assertAll();*/
	  }
 

