package POC;


import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class cart_page {
	 WebDriver dr;
		public cart_page(WebDriver dr) {
			this.dr=dr;
		}
		public void verify_product(){
			String s1=dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div[1]/div[2]/div[2]/div/div[1]/h1/span")).getText();
			System.out.println("product name is::"+s1);
		}
		
public void add_to_cart1() {
	ArrayList<String> tabs2 = new ArrayList<String> (dr.getWindowHandles());
    dr.switchTo().window(tabs2.get(1));
	try {
	
		Thread.sleep(4000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	String s=dr.getTitle();
	System.out.println(s);
	//dr.manage().window().maximize();
	//dr.findElement(By.className("col col-6-12")).click();
	
	  /*WebDriverWait wait = new WebDriverWait(dr, 10);
	    dr.findElement(By.id("navigationPageButton")).click();

	    try {
	       wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("div.t-0M7P._3GgMx1._2doH3V div._3e7xtJ div._1HmYoV.hCUpcT:nth-child(1) div._1HmYoV._35HD7C.col-5-12._3KsTU0:nth-child(1) div.bhgxx2.col-12-12:nth-child(2) div._1k1QCg._3QNwd7 ul.row li.col.col-6-12:nth-child(1) > button._2AkmmA._2Npkh4._2MWPVK")));
	    } catch (Exception e) {
	        System.out.println("Oh");
	    }
	    dr.findElement(By.cssSelector("div.t-0M7P._3GgMx1._2doH3V div._3e7xtJ div._1HmYoV.hCUpcT:nth-child(1) div._1HmYoV._35HD7C.col-5-12._3KsTU0:nth-child(1) div.bhgxx2.col-12-12:nth-child(2) div._1k1QCg._3QNwd7 ul.row li.col.col-6-12:nth-child(1) > button._2AkmmA._2Npkh4._2MWPVK")).click();
	*/
//	dr.findElement(By.xpath("//div[@id='container']//div[1]//div[3]//div[2]//div[1]//div[1]//div[2]//button[@class='_2AkmmA _2Npkh4 _2MWPVK']")).click();
    dr.findElement(By.xpath("//*[text()='ADD TO CART']")).click();
    
}
}
