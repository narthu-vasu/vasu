package POC;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_op {
	public static String[][] testdata;
	public static int rowno;
	
	public static void main(String[] args) {
		for(int i=1;i<=1;i++) {
			get_test_data(i);
		}
			
	}
	public static void get_test_data(int rowno)
	{
		//Desktop\\
		File f=new  File("C:\\Users\\n.rao\\Desktop\\poc.xlsx");
		try {
			testdata=new String[1][3];
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow r=sh.getRow(rowno);
			XSSFCell c1=r.getCell(0);
			System.out.println("asdfg");
			testdata[rowno-1][0]=c1.getStringCellValue();
			
			XSSFCell c2=r.getCell(1);
			testdata[rowno-1][1]=c2.getStringCellValue();
			
			XSSFCell c3=r.getCell(2);
			testdata[rowno-1][2]=c3.getStringCellValue();
			
			System.out.println(testdata[0][0]);
			System.out.println(testdata[0][1]);
			System.out.println(testdata[0][2]);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
