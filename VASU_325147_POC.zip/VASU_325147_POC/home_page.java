package POC;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class home_page {
	WebDriver dr;
	public home_page(WebDriver dr) {
		this.dr=dr;
	}   
	
	public void verifyuser() {
		String s=dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[3]/div/div/div/div")).getText();
		System.out.println("username::"+s);
	}
	public void search() {
		dr.findElement(By.xpath("//input[@placeholder='Search for products, brands and more']")).sendKeys("wireless earphones");
	
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("dsjhhdj");
		dr.findElement(By.xpath("//body/div[@id='container']/div/div[@class='_3ybBIU']/div[@class='_1tz-RS']/div[@class='_3pNZKl']/div[@class='Y5-ZPI']/form[@class='_1WMLwI header-form-search']/div[@class='col-12-12 _2tVp4j']/button[@class='vh79eN']/*[1]")).click();
		//System.out.println(s);
	}
	

	public void click_cart() {
		dr.findElement(By.xpath("//div[@class='shopping_cart_container']")).click();
		////*[@id="shopping_cart_container"]/a/svg/path
	}

}
