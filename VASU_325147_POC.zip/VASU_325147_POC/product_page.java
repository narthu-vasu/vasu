package POC;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class product_page {
	 WebDriver dr;
		public product_page(WebDriver dr) {
			this.dr=dr;
		}
		public void click_rate() {
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div[1]/div[1]/div[2]/div[1]/div/section[6]/div/div")).click();
			dr.findElement(By.xpath("//section[6]//div[2]//div[1]//div[1]//div[1]//div[1]//label[1]//div[2]")).click();
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		WebElement wel=dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div/div[1]/div/div[1]/div/section[2]/div[4]/div[3]/select"));
		Select sel=new Select(wel);
		sel.selectByValue("1500");
	
			
			//dr.findElement(By.xpath(xpathExpression))
		}
		public void add_to_cart() {
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			dr.findElement(By.xpath("//*[@id=\"container\"]/div/div[3]/div[2]/div/div[2]/div[2]/div/div[1]/div")).click();
		}

}
