package ASSESSMENT3;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class NewTest1 {
  @Test
  public void t1() {
	  String kw, l, td;
		WebDriver dr=null;

		methods m=new methods(dr);

		read_excel r=new read_excel();
		for(int i=0;i<5;i++) {
			kw=r.read(i,1);
			l=r.read(i,2);
			td=r.read(i,3);
			switch(kw)
			{
			case "launchChrome":
				m.launchChrome(td);
				break;
			case "enter_txt":
				m.enter_txt(l,td);
				break;
			case "verify":
				int x=m.verify(l, td);
				r.write(x, i, 4);
			
				break;
			case "click_btn":
				m.click(l);
				break;
			}
		}
	}
	  
	  
	  
  }

