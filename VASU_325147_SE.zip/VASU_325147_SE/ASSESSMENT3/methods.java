package ASSESSMENT3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class methods {
	WebDriver dr;
	methods(WebDriver dr){
		this.dr=dr;
	}
	public void enter_txt(String xp, String data) {
		dr.findElement(By.xpath(xp)).sendKeys(data);
	}
	public void click(String xpath) {
		dr.findElement(By.xpath(xpath)).click();
	}
	public int verify(String xpath, String data) {
		int f=0;
		String s;
		s=dr.findElement(By.xpath(xpath)).getText();
		if(s.equals("vasu narthu")) {
			System.out.println("Login success");
			f=1;
		}else {
			System.out.println("Login fail");
			
		}
		return f;
	}
	public void launchChrome(String url) {
		System.setProperty("webdriver.chrome.driver", "chromedriver_v78.exe");
		dr=new ChromeDriver();
		dr.get(url);
	}
	

}
