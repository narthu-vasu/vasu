package JENKINS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class NewTest1 {
	
  @Test
  public void f() {
	  System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
	WebDriver  dr=new ChromeDriver();
	  dr.get("https://www.flipkart.com");
  }
}
