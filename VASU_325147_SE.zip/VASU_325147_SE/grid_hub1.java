package GL_B2_SEL;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class grid_hub1 {
WebDriver dr;
String acturl,nodeurl;
@BeforeClass
public void setup() throws MalformedURLException
{
	acturl="https://www.facebook.com";
	nodeurl="http://172.16.135.172:5566/wd/hub";
	DesiredCapabilities cap=DesiredCapabilities.firefox();
	cap.setBrowserName("firefox");
	cap.setPlatform(Platform.WINDOWS);
	dr=new RemoteWebDriver(new URL(nodeurl),cap);	
}
@Test
public void t() {
	dr.get("https://www.facebook.com");
	
}
	
}
