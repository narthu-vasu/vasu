package PKG1;

import org.testng.annotations.Test;

public class test1 {
  @Test
  public void f() {
	  System.out.println("maven3 pkg_1 test1");
  }
}
