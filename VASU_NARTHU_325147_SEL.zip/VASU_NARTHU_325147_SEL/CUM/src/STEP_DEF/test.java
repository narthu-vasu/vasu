package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test {
	static WebDriver dr;
	@Given("^Login page is displayed$")
	public void login_page_is_displayed() throws Throwable {
		System.out.println("login page is displayed");
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		 dr=new ChromeDriver();
        dr.get("http://demowebshop.tricentis.com");
	   
	}

	@When("^User enters Login data and clicks ok button$")
	public void user_enters_Login_data_and_clicks_ok_button() throws Throwable {
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("vasunarthu7@gmail.com");
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("vasu1234");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	  
	}

	@Then("^home page is displayed$")
	public void home_page_is_displayed() throws Throwable {
	 String s=  dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	 System.out.println(s);
	 SoftAssert sa=new SoftAssert();
		sa.assertEquals(s,"vasunarthu17@gmail.com");
		sa.assertAll();
	   }


}
