package TEST_RUNNER;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="FEATURES",
                  tags="ROUND1" ,  glue="STEP_DEF")


public class testrunner  extends AbstractTestNGCucumberTests{

}
