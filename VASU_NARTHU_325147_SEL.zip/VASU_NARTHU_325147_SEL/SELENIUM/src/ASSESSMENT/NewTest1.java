package ASSESSMENT;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import SDAY6.testdata1;

public class NewTest1 {
  
	@Test
	public void t1() {
		
		
		testdata1 t2 = null;
		String k = null,x = null,d = null,r=null;
		
		WebDriver dr = null;
		
		pgm2 p=new pgm2(dr);
		pgm1 p1=new pgm1();
		for(int i=1;i<=17;i++) {
			t2=new testdata1();
			
			t2=p1.readexcel(i);
			if(i==6) {
				r=t2.data;
			}
			k=t2.keyword;
			if(i!=1) {
			x=t2.xpath;
			}
			d=t2.data;
			
		
		
		switch(k)
		{
	
		case "launchchrome":
			System.out.println("abc");
			p.launchchrome(d);
			break;
		case "enter_txt":
			
			p.enter_txt(x,d);
			break;
		case "click":
			p.click(x);
			break;
		//case "verify":
		//	r=p.verify(x);
		case "close":
			p.close();
			
		}
	
		}
		System.out.println(r);
		//t2.data=r;
		p1.write(t2);
	}
	
		
	}

