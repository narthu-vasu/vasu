package ASSESSMENT;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest2 {
	pgm3 pg=new pgm3();
	testdata3 t,t1;
	@BeforeClass
	public void A() {
		t=new testdata3();
		t1=new testdata3();
		
	}
	@Test(dataProvider="security")
	public void login( String g,String f,String l,String e ,String p,String cp) {
		t.gender=g;
		t.firstname=f;
		t.lastname=l;
		t.email=e;
		t.password=p;
		t.cpassword=cp;
		t1=pg.registration(t);
	
	}
	@DataProvider(name="security")
	public String[][] getdata(){
		String[][] d= {
				{"male","vasu","narthu","vasunarthu1223@gmail.com","vasu1234","vasu1234"},
				{"male","ramu","narthu","vasunarthu2143@gmail.com","vasu12","vasu12"}
			
		};
		return d;
	}
	@Test
	public void B() {
		if(t1.act_res.equals(t.exp_res)) {
			System.out.println(t1.act_res);
		}
		
		System.out.println(t1.act_res);
	//	SoftAssert sa=new SoftAssert();
	//	sa.assertEquals(t1.act_res, t.exp_res);
	//	sa.assertAll();
		
	}
	
}
