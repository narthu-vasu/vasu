package ASSESSMENT;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import SDAY6.testdata1;

public class pgm1 {
	static int i;
	public static void main(String[] args) {
		readexcel( i);
	}
	public static  testdata1 readexcel(int i) {
		testdata1 t=new testdata1();
		try {
			File f=new File("D:\\sample\\Book1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet7");
			XSSFRow r=sh.getRow(i);
			XSSFCell c=r.getCell(3);
			t.keyword=c.getStringCellValue();
			XSSFCell c1=r.getCell(4);
			t.xpath=c1.getStringCellValue();
			XSSFCell c2=r.getCell(5);
			//System.out.println("uid::"+t.uid+"  "+t.password);
			t.data=c2.getStringCellValue();
			XSSFCell c3=r.getCell(3);
			System.out.println("uid::"+t.keyword+"  "+t.xpath+" "+t.data);
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return t;
	}
	public void write(testdata1 d1) {
		try {
			File f=new File("D:\\sample\\Book1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet7");
			XSSFRow r=sh.getRow(11);
			XSSFCell c=r.createCell(6);
			c.setCellValue(d1.result);
			}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		
	}
		
	}

	


