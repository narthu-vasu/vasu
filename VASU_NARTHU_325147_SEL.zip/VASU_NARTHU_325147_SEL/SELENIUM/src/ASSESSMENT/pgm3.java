package ASSESSMENT;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm3 {
	public testdata3 registration(testdata3 d) {
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
		if(d.gender.equals("male")) {
			dr.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
		}
		else {
			dr.findElement(By.xpath("//*[@id=\"gender-female\"]")).click();
		}
		dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(d.firstname);
		dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(d.lastname);
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(d.email);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(d.password);
		dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(d.cpassword);
		dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		//dr.findElement(By.))
		return d;
	
	}

}
