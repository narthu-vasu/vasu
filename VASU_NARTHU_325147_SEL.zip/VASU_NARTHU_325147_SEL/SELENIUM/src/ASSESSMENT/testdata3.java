package ASSESSMENT;

public class testdata3 {

	public String gender,firstname,lastname,email,password,cpassword,act_res,exp_res;
}
