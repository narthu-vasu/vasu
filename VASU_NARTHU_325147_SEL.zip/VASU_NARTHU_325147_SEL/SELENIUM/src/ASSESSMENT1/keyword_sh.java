package ASSESSMENT1;

public class keyword_sh {
	public String tc_id;
	public String steps;
	public String keyword;
	public String xpath;
	public String tdata;

}
