package ASSESSMENT1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class methods {
	WebDriver dr;
	public void enter_txt(String xp,String data1) {
		System.out.println(data1);
		System.out.println(xp);
		dr.findElement(By.xpath(xp)).sendKeys(data1);
		
	}
	public void click(String xp) {
		dr.findElement(By.xpath(xp)).click();
	}
	public void launchchrome(String url) {
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		    dr=new ChromeDriver();
		   dr.get(url);
	}
	/*	public String verify(String xp) {
		String s=((WebElement) dr.findElements(By.xpath(xp))).getText();
		return s;
		}
		if(td.exp_res.equals(td.act_res)){
		td.result="pass";
		}
		else{
		td.result="fail";
		}
		
	}*/
	public void close() {
		// TODO Auto-generated method stub
		dr.close();
		
	}

	
	
}
