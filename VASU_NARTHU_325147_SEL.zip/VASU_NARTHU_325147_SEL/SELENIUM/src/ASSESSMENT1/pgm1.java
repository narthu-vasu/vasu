package ASSESSMENT1;

import java.io.IOException;

public class pgm1 extends readexcel{
	static keyword_sh d=new keyword_sh();
	static tc_selection td=new tc_selection();
	static methods m=new methods();
	public static void main(String a[]) throws IOException{
		String id,ch,testdata=null;//ch=null;
		int i,j,k=0;
		for(i=1;i<=3;i++) {
			td=read_tc_selection(i);
			System.out.println(td.flag);
			System.out.println(td.tc_id);
			if(td.flag.equals("y")) {
				for(j=1;j<10;j++) {
					d=read_keyword_sh(j);
					System.out.println("tc_ic"+d.tc_id);
					if(td.tc_id.equals(d.tc_id))
					{
						System.out.println("yes");
						//System.out.println(d.keyword);
						break;
					
					}
					else
						continue;
				
				}
				//System.out.println(d.keyword);
				for(int l=j;l<10;l++) {
					d=read_keyword_sh(l);
				//	System.out.println(d.keyword);
					String s=d.keyword;
					switch(s) {
					case "launchchrome":
						m.launchchrome(d.tdata);
					case "click":
					    m.click(d.tdata);
					case "enter_txt":
					    m.enter_txt(d.xpath,d.tdata); 
					case "close":
						m.close();
					}
					
				}
			}
		}
	}
}
