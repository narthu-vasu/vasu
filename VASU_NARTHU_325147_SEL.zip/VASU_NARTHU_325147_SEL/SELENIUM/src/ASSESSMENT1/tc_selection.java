package ASSESSMENT1;

public class tc_selection {
	public String tc_id;
	public String flag;
	public int no_of_steps;
	public String test_data_sheet;
	public String test_result;
	
}
