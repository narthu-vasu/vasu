package HFW;

import java.io.IOException;

public class hfw extends readexcel{
	static keyword_sh d=new keyword_sh();
	static tc_selection td=new tc_selection();
	static methods m=new methods();
	public static void main(String a[]) {
		String id,ch,testdata=null;//ch=null;
		int i,j,k=0;
		for(i=1;i<=3;i++) {
			td=read_tc_selection(i);
			System.out.println(td.flag);
			if(td.flag.equals("y")) {
				for(j=1;j<18;j++) {
					d=readexcel.read_keyword_sh(j);
					System.out.println("tc_ic"+d.tc_id);
					if(d.tc_id.equals(td.tc_id))
					{
						System.out.println("yes");
						break;
					
					}
					else
						continue;
				}
				
					System.out.println(d.keyword);
					ch=d.keyword;
					switch(ch) {
					case "launchchrome":
						m.launchchrome(d.tdata);
					case "click":
					    m.click(d.tdata);
					case "enter_txt":
					    m.enter_txt(d.xpath,d.tdata); 
					}
				}
			}
		}
	}


