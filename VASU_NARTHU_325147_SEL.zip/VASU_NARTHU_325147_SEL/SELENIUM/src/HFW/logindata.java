package HFW;

public class logindata {
public String uid;
public String password;
}
