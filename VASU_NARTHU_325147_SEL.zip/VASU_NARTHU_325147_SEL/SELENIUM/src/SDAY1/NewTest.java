package SDAY1;

import org.testng.annotations.Test;

public class NewTest {
  @Test
  public void f() {
	  System.out.println("in test f");
  }
  @Test
  public void f1() {
	  System.out.println("in test f1");
  }
}
