package SDAY1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
   WebDriver dr=new ChromeDriver();
   dr.get("https://www.facebook.com");
  /* String title=dr.getTitle();
   System.out.println("title:"+title);
   List rb=dr.findElements(By.name("sex"));
  ((WebElement) rb.get(0)).click();*/
   
  /* WebElement we1=dr.findElement(By.id("day"));
   Select sel1=new Select(we1);
   sel1.selectByVisibleText("10");
   WebElement we2=dr.findElement(By.id("month"));
   Select sel2=new Select(we2);
   sel2.selectByVisibleText("May");*/
   dr.findElement(By.name("email")).sendKeys("9652096971");
   dr.findElement(By.name("pass")).sendKeys("9676091252");
  dr.findElement(By.xpath("//*[@id=\"loginbutton\"]")).click();
  // dr.findElement(By.name("login")).click();
  String a_profilename=dr.findElement(By.xpath("//*[@id=\"u_0_a\"]/div[1]/div[1]/div/a/span/span")).getText();
  String e_profilename="vasu";
  if(e_profilename.compareTo("")==0) {
	  System.out.println("login successful");
  }
  else {
	  System.out.println("login not successful");
  }
	}

}
