package SDAY2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm3{
	public static void main(String[] args) {
	  System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
	   WebDriver dr=new ChromeDriver();
	   dr.get("https://www.w3schools.com/html/html_tables.asp");
	  
	  String str=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[1]/th[1]")).getText();
	   System.out.print(str);
		 /*String str1=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[1]/th[2]")).getText();
		   System.out.print(str1);
			  String str2=dr.findElement(By.xpath("//*[@id=\"customers\"]/tbody/tr[1]/th[3]")).getText();
			   System.out.print(str2);*/
		   
}
}