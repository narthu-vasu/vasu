package SDAY3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		   WebDriver dr=new ChromeDriver();
		   dr.get("https://ultimateqa.com/simple-html-elements-for-automation/");
		   dr.findElement(By.xpath("//*[@id=\"et-boc\"]/div/div/div[2]/div/div[3]/div/div/div/div/form/button")).click();
		   String s=dr.findElement(By.xpath("//*[@id=\"post-4690\"]/div[1]/h1")).getText();
		   if(s.equals("Button success")) {
			   System.out.println("pass");
		   }
		   else {
			   System.out.println("fail");
		   }

	}

}
