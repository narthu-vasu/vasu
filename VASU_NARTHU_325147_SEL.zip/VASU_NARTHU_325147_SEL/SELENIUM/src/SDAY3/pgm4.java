package SDAY3;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm4 {
static details testdata;
static details data;
	public static details read_excel() {
		details d=new details();
		try {
			File f=new File("D:\\sample\\Book1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet2");
			XSSFRow r=sh.getRow(1);
			XSSFCell c=r.getCell(0);
			d.uid=c.getStringCellValue();
			XSSFCell c1=r.getCell(1);
			d.password=c1.getStringCellValue();
			XSSFCell c2=r.getCell(2);
			d.exp_res=c2.getStringCellValue();
			System.out.println(d.uid+" "+d.password+" "+d.exp_res);
			
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return d;
	}
	public static details login() {
		   System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		   WebDriver dr=new ChromeDriver();
		   dr.get("http://demowebshop.tricentis.com/login");
		   dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(testdata.uid);
		   dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(testdata.password);
		   dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
testdata.act_res=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
if(testdata.uid.equals(testdata.act_res)) {
	 testdata.test_res="pass";
}
else {
  testdata.test_res="fail";
}
return testdata;
	}
	public static void write_excel(details a) {

		
		try {
			File f=new File("D:\\sample\\Book1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet2");
			XSSFRow r=sh.getRow(1);
			XSSFCell c=r.createCell(3);
			c.setCellValue(a.act_res);
			XSSFCell c1=r.createCell(4);
		     c1.setCellValue(a.test_res);
		     FileOutputStream fos=new FileOutputStream(f);
		     wb.write(fos);
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] arg) {
	
		testdata=read_excel();
		testdata=login();
		write_excel(testdata);
	}
}