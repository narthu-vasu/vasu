package SDAY3;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm5 {
public static user data;
	public static void main(String[] args) {
		data=read_excel();
		registration();
		write_excel(data);
	}
	public static user read_excel() {
		user u=new user();
		try {
			File f=new File("D:\\sample\\Book1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet3");
			XSSFRow r=sh.getRow(1);
			XSSFCell c=r.getCell(0);
			u.fistname=c.getStringCellValue();
			XSSFCell c1=r.getCell(1);
			u.lastname=c1.getStringCellValue();
			XSSFCell c2=r.getCell(2);
			u.mailid=c2.getStringCellValue();
			XSSFCell c3=r.getCell(3);
			u.password=c3.getStringCellValue();
			XSSFCell c4=r.getCell(4);
			u.exp_res=c4.getStringCellValue();
			System.out.println(u.fistname+" "+u.lastname+" "+u.mailid+" "+u.exp_res);
			
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return u;
	}
		// TODO Auto-generated method stub
		public static void registration() {
		   System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		   WebDriver dr=new ChromeDriver();
		   dr.get("http://demowebshop.tricentis.com");
dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).click();
String s=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/form/div/div[1]/h1")).getText();
//title verification
 String title=dr.getTitle();
System.out.println("title:"+title);
if(title.equals("Demo Web Shop. Register")) {
	System.out.println("title verified");
}
else {
	System.out.println("fail");
}
dr.findElement(By.xpath("//*[@id=\"gender-male\"]")).click();
dr.findElement(By.xpath("//*[@id=\"FirstName\"]")).sendKeys(data.fistname);
dr.findElement(By.xpath("//*[@id=\"LastName\"]")).sendKeys(data.lastname);
dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(data.mailid);
dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(data.password);
dr.findElement(By.xpath("//*[@id=\"ConfirmPassword\"]")).sendKeys(data.password);
dr.findElement(By.xpath("//*[@id=\"register-button\"]")).click();
//reg verification
data.act_res=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]")).getText();

if(data.act_res.equals(data.exp_res)) {
	data.result="pass";
}
else {
	data.result="fail";
}
//mail verification
String s1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
if(data.mailid.equals(s1)) {
	System.out.println("mail verified");
	dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
}
else {
	System.out.println("mail not verified");
}

	}
		public static void write_excel(user a) {

			
			try {
				File f=new File("D:\\sample\\Book1.xlsx");
				FileInputStream fis=new FileInputStream(f);
				XSSFWorkbook wb= new XSSFWorkbook(fis);
				XSSFSheet sh=wb.getSheet("Sheet3");
				XSSFRow r=sh.getRow(1);
				XSSFCell c=r.createCell(5);
				c.setCellValue(a.act_res);
				XSSFCell c1=r.createCell(6);
				c1.setCellValue(a.result);
				
			     FileOutputStream fos=new FileOutputStream(f);
			     wb.write(fos);
			}
			catch(FileNotFoundException e) {
				e.printStackTrace();
			}
			catch(IOException e) {
				e.printStackTrace();
			}
		}

}
