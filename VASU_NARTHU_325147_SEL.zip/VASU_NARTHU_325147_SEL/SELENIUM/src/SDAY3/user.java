package SDAY3;

public class user {
public String fistname;
public String lastname;
public String mailid;
public String password;
public String exp_res;
public String act_res;
public String result;

}
