package SDAY4;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
        dr.get("https://www.naukri.com/");
        String h=dr.getWindowHandle();
        for(String handle:dr.getWindowHandles()) {
        	dr.switchTo().window(handle);
        	String t1 = dr.getCurrentUrl();
        	System.out.println(t1);
        	String t2 = dr.getTitle();
        	System.out.println(t2);
        	
        }

	}

}
