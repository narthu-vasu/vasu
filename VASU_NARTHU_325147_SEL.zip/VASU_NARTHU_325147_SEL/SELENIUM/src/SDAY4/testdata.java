package SDAY4;

public class testdata {
	public String uid;
	public String password;
	public String exp_res;
	public String exp_em1;
	public String exp_em2;
	public String act_res;
	public String act_em1;
	public String act_em2;
	public String testresult;
	

}
