package SDAY5;

import org.testng.annotations.Test;

public class NewTest3 {
	pgm1 p=new pgm1();
	testdata t,t1;
  @Test
  public void test() {
	  t=new testdata();
	  t1=new testdata();
	  t.uid="vasunarthu7@gmail.com";
	  t.password="vasu1234";
	  t.exp_res="success";
	t1= p. login(t);
	System.out.println("actualresult"+t.act_res+" "+" testresult"+t1.testresult+" ");
  }

}
