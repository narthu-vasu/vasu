package SDAY5;

import java.util.ArrayList;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class NewTest5 {
	pgm2 p=new pgm2();
	ArrayList<testdata> al_t;
	ArrayList<testdata> al_t1;
	  @BeforeClass
 public void t1() {
		  al_t=new ArrayList<testdata>();
		al_t= p.readexcel();
	  }
	  @Test
	  public void t2() {
		  p.login(al_t,1);
	  }
	  @Test
	  public void t3() {
		  p.login(al_t,2);
	  }
	  @Test
	  public void t4() {
		  p.login(al_t,3);
	  }
	  @Test
	  public void t5() {
		 al_t1= p.login(al_t,4);
	  }
	  @AfterClass
	  public void t6() {
		  p.writeexcel(al_t1);
	  }

}
