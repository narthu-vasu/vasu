package SDAY6;

import org.testng.annotations.Test;

public class NewTest1 {
  @Test(priority=0)
  public void f1() {
	  System.out.println("in test f1");
  }
  @Test(priority=2)
  public void f2() {
	  System.out.println("in test f2");
  }
  @Test(priority=1)
  public void f3() {
	  System.out.println("in test f3");
  }

}
