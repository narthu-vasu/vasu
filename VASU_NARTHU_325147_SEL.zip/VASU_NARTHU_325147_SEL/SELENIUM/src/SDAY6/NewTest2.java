package SDAY6;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class NewTest2 {
  @Test
  public void a() {
	  String a="noida";
	  String b="noida";
	  Assert.assertEquals(a,b);
	  System.out.println("in test a");
  }
  @Test
  public void b() {
	  String a="noida";
	  String b="noida1";
	 SoftAssert sa=new SoftAssert();
	  sa.assertEquals(a,b);
	  System.out.println("in test b1");
	  System.out.println("in test b2");
	  sa.assertAll();
  }
  @Test
  public void c() {
	  String a="noida";
	  String b="noida1";
	  Assert.assertEquals(a,b);
	  System.out.println("in test c");
  }
}
