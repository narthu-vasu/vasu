package SDAY6;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import SDAY5.pgm1;
import SDAY5.testdata;

public class NewTest3 {
	pgm1 p=new pgm1();
	testdata t,t1;
  @Test
  public void test1() {
	  t=new testdata();
	  t1=new testdata();
	  t.uid="vasunarthu7@gmail.com";
	  t.password="vasu1234";
	  t.exp_res="success";
	t1= p. login(t);
	SoftAssert sa=new SoftAssert();
	sa.assertEquals(t.exp_res,t1.act_res );
	System.out.println("actualresult::"+t.act_res+" "+" testresult::"+t1.testresult+" ");
	sa.assertAll();
  }
  @Test
  public void test2() {
	  t=new testdata();
	  t1=new testdata();
	  t.uid="vasunarthu7@gmail.com";
	  t.password="vasu";
	  t.exp_res="success";
	t1= p. login(t);
	SoftAssert sa=new SoftAssert();
	sa.assertEquals(t.exp_res,t1.act_res );
	System.out.println("actualresult::"+t.act_res+" "+" testresult::"+t1.testresult+" ");
	sa.assertAll();
  }
}
