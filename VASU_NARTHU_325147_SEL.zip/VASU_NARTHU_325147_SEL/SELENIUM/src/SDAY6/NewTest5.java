package SDAY6;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import SDAY5.testdata;

public class NewTest5 {
	pgm2 pg=new pgm2();
	testdata t,t1;
	@BeforeClass
	public void a() {
		t=new testdata();
		t1=new testdata();
		
	}
	@Test(dataProvider="security")
	public void login(String u,String p,String r ) {
		t.uid=u;
		t.password=p;
		t.exp_res=r;
		t1=pg.login(t);
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(t1.act_res, t.exp_res);
		sa.assertAll();
		
	}
	@DataProvider(name="security")
	public String[][] getdata(){
		String[][] d= {
				{"vasunarthu7@gmail.com","vasu1234","success"},
				{"vasunarthu@gmail.com","vasu","failure"}
			
		};
		return d;
	}
	
}
