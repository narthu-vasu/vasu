package SDAY6;

import org.testng.annotations.Test;

public class NewTest6 {
  @Test
  public void f() {
  }
}
