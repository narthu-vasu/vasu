package SDAY6;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import SDAY5.testdata;

public class pgm1 {


public static testdata login(testdata tdata2) {
		// TODO Auto-generated method stub
	
		System.setProperty("webdriver.chrome.driver","chromedriver_v78.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a")).click();
		dr.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys(tdata2.uid);
		dr.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys(tdata2.password);
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		boolean f=dr.getTitle().contains("Login");
		//System.out.println(f);
		if(!f) {
			tdata2.act_res="success";
			System.out.println("login successful");
		}
		else {
			tdata2.act_res="failure";
		}
		if(tdata2.exp_res.equals(tdata2.act_res)) {
	 
				tdata2.testresult="pass";
			}
			else {
				tdata2.testresult="fail";
			}
		
		return tdata2;
	}
}
