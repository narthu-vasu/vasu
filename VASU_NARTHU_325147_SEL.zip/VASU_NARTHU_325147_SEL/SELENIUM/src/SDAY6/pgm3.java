package SDAY6;

import org.openqa.selenium.WebDriver;

public class pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		testdata1 t2;
		String k = null,x = null,d = null;
		
		WebDriver dr = null;
		
		pgm4 p=new pgm4(dr);
		pgm5 p1=new pgm5();
		for(int i=1;i<=4;i++) {
			t2=new testdata1();
			t2=p1.readexcel(i);
			k=t2.keyword;
			if(i!=1) {
			x=t2.xpath;
			}
			d=t2.data;
			
		
		
		switch(k)
		{
	
		case "launchchrome":
			System.out.println("abc");
			p.launchchrome(d);
			break;
		case "enter_txt":
			
			p.enter_txt(x,d);
			break;
		case "click":
			p.click(x);
			break;
			
		}
		}
	}

}
