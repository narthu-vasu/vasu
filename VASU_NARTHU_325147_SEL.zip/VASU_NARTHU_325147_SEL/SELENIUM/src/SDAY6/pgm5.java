package SDAY6;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class pgm5 {
	static int i;
	public static void main(String[] args) {
		readexcel( i);
	}
	public static  testdata1 readexcel(int i) {
		testdata1 t=new testdata1();
		try {
			File f=new File("D:\\sample\\Book1.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb= new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet6");
			XSSFRow r=sh.getRow(i);
			XSSFCell c=r.getCell(1);
			t.keyword=c.getStringCellValue();
			XSSFCell c1=r.getCell(2);
			t.xpath=c1.getStringCellValue();
			XSSFCell c2=r.getCell(3);
			//System.out.println("uid::"+t.uid+"  "+t.password);
			t.data=c2.getStringCellValue();
			XSSFCell c3=r.getCell(3);
			System.out.println("uid::"+t.keyword+"  "+t.xpath+" "+t.data);
		}
		catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		catch(IOException e) {
			e.printStackTrace();
		}
		return t;
	}
}
