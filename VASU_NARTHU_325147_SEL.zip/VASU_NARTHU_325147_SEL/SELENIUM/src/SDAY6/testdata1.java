package SDAY6;

public class testdata1 {

	public String keyword,xpath,data,exp_res,act_res,result;
}
