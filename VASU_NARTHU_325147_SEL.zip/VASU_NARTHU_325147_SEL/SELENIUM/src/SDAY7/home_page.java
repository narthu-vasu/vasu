package SDAY7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class home_page {
	WebDriver dr;
	String base_xp="//div[@class='inventory_item'][";
	By xname,xprice,xbtn;
	public home_page(WebDriver dr) {
		this.dr=dr;
	}
	public String get_product_name(int n) {
		xname=By.xpath(base_xp+n+"]//div[@class='inventory_item_name']");
		String pname=dr.findElement(xname).getText();
		return pname;
	}
	public void add_to_cart(int n) {
		xbtn=By.xpath(base_xp+n+"]//button");
		dr.findElement(xbtn).click();
	}
	public void click_cart() {
		dr.findElement(By.xpath("//div[@class='shopping_cart_container']")).click();
		////*[@id="shopping_cart_container"]/a/svg/path
	}

}
