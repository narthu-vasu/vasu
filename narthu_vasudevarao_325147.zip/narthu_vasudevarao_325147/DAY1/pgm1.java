package DAY1;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("java hello world");
		int n=100,i,j,s=0,k=0;
		
		for(i=1;i<n;i++) {
			 int c=0;
			for(j=1;j<n;j++) {
				if(i%j==0) {
					c++;
				}
			}	
		if(c==2) {
			System.out.print(" "+i);
			s=s+i;
			k++;
		}
		if(k==10) {
		System.out.println("\n"+s);
		break;
		}
	}
	}
	
}
