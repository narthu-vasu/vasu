package DAY1;

import java.util.Scanner;

public class pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a;
		int b;
		int c;
		float avg;
		int total_marks;
		 Scanner sc=new Scanner(System.in);
			System.out.println("enter sub1 marks");
			a=sc.nextInt();
			System.out.println("enter sub2 marks");
			b=sc.nextInt();
			System.out.println("enter sub3 marks");
			c=sc.nextInt();
			total_marks=a+b+c;
			System.out.println("total_marks"+total_marks);
			avg=(float)(a+b+c)/3;
			System.out.println("avg score"+avg);
			if(avg>=60)
				System.out.println("first class");
			if(50<=avg&&avg<60)
				System.out.println("secondclass");
            if(35<=avg&&avg<50)
            	System.out.println("pass class");
            else
            	System.out.println("fail");
            
            
            
	}

}
