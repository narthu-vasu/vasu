package DAY2;

import java.util.Scanner;

public class pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n;
	    int k;
	    int s=0;
		 Scanner sc=new Scanner(System.in);
			System.out.println("enter number");
			n=sc.nextInt();
			while(n!=0) {
				k=n%10;
				if(k>5) {
					s=s+k;
				}
				n=n/10;
			}
			
			System.out.println("sum is "+s);
	}

}
