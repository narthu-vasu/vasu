package DAY2;

public class pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=15,s=0;
		while(i<75)
		 {
			if(i%7==0)
			{
					System.out.print(" "+i);
					s=s+i;
			}
			i++;
		}

System.out.println(" sum"+s);
	}

}
