package DAY3;

public class College {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student rakesh=new Student();
		rakesh.rollnum=1;
		rakesh.name="rakesh";
		rakesh.m1=91;
		rakesh.m2=95;
System.out.println(rakesh.rollnum);
System.out.println(rakesh.name);
System.out.println(rakesh.m1);
System.out.println(rakesh.m2);
rakesh.average();
System.out.println(rakesh.avg);
Student priya=new Student();
priya.rollnum=2;
priya.name="priya";
priya.m1=75;
priya.m2=85;
System.out.println(priya.rollnum);
System.out.println(priya.name);
System.out.println(priya.m1);
System.out.println(priya.m2);
priya.average();
System.out.println(priya.avg);
	}

}
