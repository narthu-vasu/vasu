package DAY3;

public class Student {

int rollnum;
String name;
int m1;
int m2;
float avg;


public void average() {
	this.avg=(this.m1+this.m2)/2;
	
}
}
