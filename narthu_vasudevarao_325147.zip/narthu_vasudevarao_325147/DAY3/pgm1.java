package DAY3;

public class pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int  std[]= {55,57,78,85,84,90};
		float avg;
		int s=0;
		for(int i=0;i<=5;i++) {
			s=s+std[i];
		}
		avg=(float)s/6;
System.out.println(s);
System.out.println(avg);
	}

}
